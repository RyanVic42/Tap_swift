// Global JavaScript functions
document.addEventListener("DOMContentLoaded", () => {
  // Initialize all components
  initializeAlerts()
  initializeForms()
  initializeModals()
})

// Alert handling
function initializeAlerts() {
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 5000)
  })
}

// Form handling
function initializeForms() {
  const forms = document.querySelectorAll("form")
  forms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      const submitBtn = form.querySelector('button[type="submit"]')
      if (submitBtn) {
        submitBtn.disabled = true
        submitBtn.textContent = "Processing..."

        setTimeout(() => {
          submitBtn.disabled = false
          submitBtn.textContent = submitBtn.getAttribute("data-original-text") || "Submit"
        }, 3000)
      }
    })
  })
}

// Modal handling
function initializeModals() {
  const modalTriggers = document.querySelectorAll("[data-modal]")
  modalTriggers.forEach((trigger) => {
    trigger.addEventListener("click", function (e) {
      e.preventDefault()
      const modalId = this.getAttribute("data-modal")
      const modal = document.getElementById(modalId)
      if (modal) {
        modal.style.display = "block"
      }
    })
  })

  const modalCloses = document.querySelectorAll(".modal-close")
  modalCloses.forEach((close) => {
    close.addEventListener("click", function () {
      const modal = this.closest(".modal")
      if (modal) {
        modal.style.display = "none"
      }
    })
  })
}

// Generate Pass function
function generatePass(username) {
  showLoading()

  fetch(`/generate_pass/${username}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((response) => response.json())
    .then((data) => {
      hideLoading()
      if (data.success) {
        showAlert("Pass generated successfully!", "success")
        location.reload()
      } else {
        showAlert(data.error || "Failed to generate pass", "error")
      }
    })
    .catch((error) => {
      hideLoading()
      showAlert("Network error occurred", "error")
      console.error("Error:", error)
    })
}

// Make Payment function
function makePayment(username) {
  const amount = document.getElementById("amount").value
  const paymentMethod = document.getElementById("payment_method").value

  if (!amount || amount < 100) {
    showAlert("Please enter a valid amount (minimum KES 100)", "error")
    return
  }

  showLoading()

  const formData = new FormData()
  formData.append("amount", amount)
  formData.append("payment_method", paymentMethod)

  fetch(`/make_payment/${username}`, {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      hideLoading()
      if (data.success) {
        showAlert(`Payment successful! New balance: KES ${data.new_balance}`, "success")
        location.reload()
      } else {
        showAlert(data.error || "Payment failed", "error")
      }
    })
    .catch((error) => {
      hideLoading()
      showAlert("Network error occurred", "error")
      console.error("Error:", error)
    })
}

// Utility functions
function showLoading() {
  const loading = document.querySelector(".loading")
  if (loading) {
    loading.style.display = "block"
  }
}

function hideLoading() {
  const loading = document.querySelector(".loading")
  if (loading) {
    loading.style.display = "none"
  }
}

function showAlert(message, type) {
  const alertDiv = document.createElement("div")
  alertDiv.className = `alert alert-${type}`
  alertDiv.textContent = message

  const container = document.querySelector(".container")
  if (container) {
    container.insertBefore(alertDiv, container.firstChild)

    setTimeout(() => {
      alertDiv.style.opacity = "0"
      setTimeout(() => {
        alertDiv.remove()
      }, 300)
    }, 5000)
  }
}

// Form validation
function validateForm(formId) {
  const form = document.getElementById(formId)
  const inputs = form.querySelectorAll("input[required], select[required]")
  let isValid = true

  inputs.forEach((input) => {
    if (!input.value.trim()) {
      input.style.borderColor = "#dc3545"
      isValid = false
    } else {
      input.style.borderColor = "#ddd"
    }
  })

  return isValid
}

// Print function
function printPass() {
  window.print()
}

// Download QR Code
function downloadQR(qrPath, filename) {
  const link = document.createElement("a")
  link.href = qrPath
  link.download = filename || "bus_pass_qr.png"
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}
