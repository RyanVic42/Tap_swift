from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
import qrcode
from PIL import Image
import os
import requests
import json
from datetime import datetime, timedelta
import uuid
import logging

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Mock database
passengers = {}
drivers = {}
admins = {"admin": {"password": "admin123", "role": "admin"}}
passes = {}
payment_history = {}
saccos = {
    "MU84": {"name": "MU84 Sacco", "routes": ["Moi University to Eldoret Town", "Moi University to Kesses"], "fleet_size": 15, "contact": "mu84@example.com"},
}
routes = [
    {"name": "Moi University to Eldoret Town", "sacco": "MU84", "schedule": ["07:00", "09:00", "12:00"], "price": 100},
    {"name": "Moi University to Kesses", "sacco": "MU84", "schedule": ["08:00", "10:00", "13:00"], "price": 50},
    {"name": "Moi University to Annex Campus", "sacco": "Moi University Shuttle", "schedule": ["07:30", "11:00", "14:00"], "price": 70},
    {"name": "Moi University to Cheptiret", "sacco": "Eldoret Express", "schedule": ["09:30", "12:30", "15:00"], "price": 80}
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']
        flash('Message sent successfully!', 'success')
        return redirect(url_for('contact'))
    return render_template('contact.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        
        if role == 'passenger' and username in passengers and passengers[username]['password'] == password:
            session['username'] = username
            session['role'] = 'passenger'
            return redirect(url_for('passenger_dashboard', username=username))
        elif role == 'driver' and username in drivers and drivers[username]['password'] == password:
            session['username'] = username
            session['role'] = 'driver'
            return redirect(url_for('driver_portal', username=username))
        else:
            flash('Invalid credentials.', 'error')
    return render_template('login.html')

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in admins and admins[username]['password'] == password:
            session['username'] = username
            session['role'] = 'admin'
            return redirect(url_for('admin_portal'))
        flash('Invalid admin credentials.', 'error')
    return render_template('admin_login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        
        if role == 'passenger' and username not in passengers:
            passenger_id = str(uuid.uuid4())
            passengers[username] = {
                'password': password, 
                'role': role, 
                'points': 0, 
                'balance': 0,
                'passenger_id': passenger_id
            }
            flash('Registration successful!', 'success')
            return redirect(url_for('login'))
        elif role == 'driver' and username not in drivers:
            drivers[username] = {'password': password, 'role': role}
            flash('Registration successful!', 'success')
            return redirect(url_for('login'))
        else:
            flash('Username already exists.', 'error')
    return render_template('register.html')

@app.route('/passenger_dashboard/<username>')
def passenger_dashboard(username):
    if 'username' not in session or session['username'] != username or session['role'] != 'passenger':
        flash('Unauthorized access.', 'error')
        return redirect(url_for('login'))
    
    user_pass = passes.get(username, {})
    user_points = passengers[username]['points']
    user_balance = passengers[username]['balance']
    user_payments = payment_history.get(username, [])
    
    return render_template('passenger_dashboard.html', 
                         username=username, 
                         routes=routes, 
                         user_pass=user_pass,
                         points=user_points, 
                         balance=user_balance, 
                         payments=user_payments)

@app.route('/driver_portal/<username>')
def driver_portal(username):
    if 'username' not in session or session['username'] != username or session['role'] != 'driver':
        flash('Unauthorized access.', 'error')
        return redirect(url_for('login'))
    return render_template('driver_portal.html', username=username, routes=routes)

@app.route('/admin_portal')
def admin_portal():
    if 'username' not in session or session['role'] != 'admin':
        flash('Unauthorized access.', 'error')
        return redirect(url_for('admin_login'))
    return render_template('admin_portal.html', 
                         passengers=passengers, 
                         drivers=drivers, 
                         routes=routes,
                         saccos=saccos)

@app.route('/generate_pass/<username>', methods=['POST'])
def generate_pass(username):
    if 'username' not in session or session['username'] != username or session['role'] != 'passenger':
        return jsonify({'error': 'Unauthorized'}), 403
    
    if passes.get(username):
        return jsonify({'success': False, 'error': 'Pass already exists'}), 400
    
    passenger_id = passengers[username]['passenger_id']
    pass_id = str(uuid.uuid4())
    validity = datetime.now() + timedelta(days=365)
    
    # Generate QR code
    qr_data = f"PassengerID:{passenger_id},PassID:{pass_id},User:{username}"
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(qr_data)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white")
    qr_path = f"static/passes/{pass_id}.png"
    qr_img.save(qr_path)
    
    passes[username] = {
        'id': pass_id, 
        'validity': validity.strftime('%Y-%m-%d'), 
        'qr_path': qr_path
    }
    passengers[username]['points'] += 10
    
    return jsonify({'success': True, 'qr_path': qr_path})

@app.route('/make_payment/<username>', methods=['POST'])
def make_payment(username):
    if 'username' not in session or session['username'] != username or session['role'] != 'passenger':
        return jsonify({'error': 'Unauthorized'}), 403
    
    amount = request.form['amount']
    payment_method = request.form.get('payment_method', 'M-Pesa')
    
    try:
        amount = int(amount)
        if amount < 100:
            return jsonify({'success': False, 'error': 'Minimum top-up amount is KES 100'}), 400
        
        passengers[username]['balance'] += amount
        passengers[username]['points'] += amount // 100
        
        payment_history[username] = payment_history.get(username, []) + [{
            'amount': amount,
            'method': payment_method,
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }]
        
        return jsonify({'success': True, 'new_balance': passengers[username]['balance']})
    except ValueError:
        return jsonify({'success': False, 'error': 'Invalid amount'}), 400

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    os.makedirs('static/passes', exist_ok=True)
    app.run(debug=True, host='0.0.0.0', port=5000)
